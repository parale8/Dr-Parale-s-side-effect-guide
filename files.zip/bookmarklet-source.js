/* ==========================================================================
   OneGlance EMR — Intolerance Conflict Flagger + Rx Side-Effect Panel
   --------------------------------------------------------------------------
   This is the readable source. The bookmarklet you paste into your browser
   bar is this same code, minified and wrapped as a single javascript: URI
   (see bookmarklet.txt).

   It fetches index.html from GitHub Pages, pulls the drug database out of
   the <script id="drug-db"> tag, then watches the Rx medicine cells and the
   Intolerance chips on the current OneGlance patient page.

   ASSUMED URL — confirm/replace if your repo path differs:
   ========================================================================== */

(function () {
  'use strict';

  const INDEX_URL = 'https://parale8.github.io/side-effect-guide/index.html';

  let DB = null;

  async function loadDB() {
    if (DB) return DB;
    const res = await fetch(INDEX_URL, { cache: 'no-store' });
    const html = await res.text();
    const match = html.match(/<script[^>]*id=["']drug-db["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!match) throw new Error('OneGlance checker: drug-db script tag not found at ' + INDEX_URL);
    DB = JSON.parse(match[1]);
    return DB;
  }

  function normalize(name) {
    return (name || '')
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, '')
      .trim();
  }

  function classesForDrug(drugName, db) {
    const n = normalize(drugName);
    const hits = [];
    for (const [classKey, classData] of Object.entries(db.classes)) {
      if (classData.drugs.some(d => n.includes(normalize(d)) || normalize(d).includes(n))) {
        hits.push(classKey);
      }
    }
    return hits;
  }

  function resolveIntoleranceToClasses(intoleranceText, db) {
    const n = normalize(intoleranceText);
    const matchedClasses = new Set();
    for (const [classKey, classData] of Object.entries(db.classes)) {
      if (classData.drugs.some(d => n.includes(normalize(d)))) {
        matchedClasses.add(classKey);
      }
    }
    return [...matchedClasses];
  }

  function checkConflict(drugName, intoleranceTexts, db) {
    const drugClasses = classesForDrug(drugName, db);
    for (const text of intoleranceTexts) {
      const intolClasses = resolveIntoleranceToClasses(text, db);
      const overlap = drugClasses.filter(c => intolClasses.includes(c));
      if (overlap.length) {
        return {
          conflict: true,
          reason: text,
          sharedClass: overlap[0],
          classLabel: db.classes[overlap[0]].label
        };
      }
    }
    return { conflict: false };
  }

  function sideEffectPanelHTML(drugName, db) {
    const classKeys = classesForDrug(drugName, db);
    if (!classKeys.length) {
      return `<div class="ic-panel-empty">No side-effect data for "${drugName}" yet.</div>`;
    }
    return classKeys.map(ck => {
      const c = db.classes[ck];
      return `
        <div class="ic-drug-block" style="margin-bottom:8px">
          <div class="ic-drug-class" style="font-weight:600">${c.label}</div>
          <div class="ic-se-group"><b>Common:</b> ${c.side_effects.common.join(', ')}</div>
          <div class="ic-se-group ic-uncommon" style="color:#555"><b>Uncommon:</b> ${c.side_effects.uncommon.join(', ')}</div>
        </div>`;
    }).join('');
  }

  /* ---------------- EMR-specific (confirmed from live DOM) ---------------- */

  function getIntoleranceTexts() {
    const labels = document.querySelectorAll('div.category_lbl');
    let intoleranceGroup = null;
    labels.forEach(lbl => {
      if (lbl.textContent.trim().toLowerCase() === 'intolerance') {
        intoleranceGroup = lbl.closest('.cs_sign_gp');
      }
    });
    if (!intoleranceGroup) return [];

    const inputSpan = intoleranceGroup.querySelector('span.category_inpt');
    if (!inputSpan) return [];

    const candidates = inputSpan.querySelectorAll('*');
    const texts = new Set();
    candidates.forEach(el => {
      if (el.children.length === 0) {
        const t = el.textContent.replace(/×\s*$/, '').trim();
        if (t) texts.add(t);
      }
    });
    if (texts.size === 0) {
      const t = inputSpan.textContent.replace(/×/g, ' ').trim();
      if (t) texts.add(t);
    }
    return [...texts];
  }

  function watchRxInputs(onDrugEntered) {
    const container = document.querySelector('.rx_treatment_tabel_edit');
    if (!container) return;

    const cells = container.querySelectorAll('.case_field_table td.treatment_type');
    cells.forEach(cell => {
      const fire = () => onDrugEntered(cell.textContent.trim(), cell);
      cell.addEventListener('input', fire);
      cell.addEventListener('keyup', fire);
      cell.addEventListener('blur', fire);
    });

    const observer = new MutationObserver(muts => {
      muts.forEach(m => {
        const cell = m.target.nodeType === 1
          ? m.target.closest?.('td.treatment_type')
          : m.target.parentElement?.closest?.('td.treatment_type');
        if (cell) onDrugEntered(cell.textContent.trim(), cell);
      });
    });
    observer.observe(container, { childList: true, subtree: true, characterData: true });
  }

  function getOrCreateSidePanel() {
    let panel = document.getElementById('ic-side-panel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'ic-side-panel';
      panel.style.cssText = 'position:fixed;right:10px;top:100px;width:280px;max-height:70vh;overflow:auto;background:#fff;border:1px solid #ccc;border-radius:8px;padding:10px;font-size:12px;z-index:99999;box-shadow:0 2px 8px rgba(0,0,0,.15)';
      document.body.appendChild(panel);
    }
    return panel;
  }

  function flagInputRed(cell, reason, classLabel) {
    cell.style.outline = '3px solid red';
    cell.title = `⚠ Patient intolerance: ${reason} — same class as: ${classLabel}. Verify before prescribing.`;
    let badge = cell.querySelector('.ic-red-flag-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.className = 'ic-red-flag-badge';
      badge.style.cssText = 'position:absolute;left:0;top:100%;color:#fff;background:red;font-size:10px;padding:1px 5px;border-radius:3px;white-space:nowrap;z-index:1000;pointer-events:none';
      cell.appendChild(badge);
    }
    badge.textContent = `⚠ ${classLabel} conflict`;
  }

  function clearFlag(cell) {
    cell.style.outline = '';
    cell.title = '';
    const badge = cell.querySelector('.ic-red-flag-badge');
    if (badge) badge.remove();
  }

  async function main() {
    let db;
    try {
      db = await loadDB();
    } catch (e) {
      alert('OneGlance checker: could not load drug database.\n' + e.message);
      return;
    }
    const intoleranceTexts = getIntoleranceTexts();

    watchRxInputs((drugName, cell) => {
      if (!drugName) return;

      const result = checkConflict(drugName, intoleranceTexts, db);
      if (result.conflict) {
        flagInputRed(cell, result.reason, result.classLabel);
      } else {
        clearFlag(cell);
      }

      const panel = getOrCreateSidePanel();
      panel.innerHTML = `<div style="font-weight:600;margin-bottom:6px">Side effects — ${drugName}</div>` +
        sideEffectPanelHTML(drugName, db);
    });
  }

  main();
})();
